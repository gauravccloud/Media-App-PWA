import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { NgxCarouselModule } from 'ngx-carousel';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { HttpModule } from '@angular/http'
import { FormsModule } from '@angular/forms';
import 'hammerjs';
import { RouterModule } from '@angular/router'
import { routing } from './app.routing';

import { SlickModule } from 'ngx-slick';

import { AppComponent } from './app.component';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { CarouselComponent } from './components/carousel/carousel.component';
import { SearchComponent } from './components/search-items/search-item.component'
import { DataService } from './app.service';
import { SearchResolve } from './search.resolve';
// import { SlickSliderComponent } from './slicker.component';


@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    CarouselComponent,
    SearchComponent
    // SlickSliderComponent
  ],
  imports: [
    BrowserModule,
    NgbModule,
    NgxCarouselModule,
    InfiniteScrollModule,
    HttpModule,
    SlickModule.forRoot(),
    RouterModule,
    FormsModule,
    routing
  ],
  providers: [DataService, SearchResolve],
  bootstrap: [AppComponent]
})
export class AppModule { }
